PWA Icon Pack — pwaicos.com

1. Copy icon files into your project public/ or static/ folder
2. Paste the icons array from manifest-icons.json into manifest.json
3. Adjust src paths to match your directory layout

Generated at pwaicos.com — processed locally in your browser.
